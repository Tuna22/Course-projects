% IOE 511/MATH 562, University of Michigan
% Code written by: Albert S. Berahas

% Function that specifies general options. 
% 
%           Input: options (struct)
%           Output: method, options (struct)
%
% Warning(s):
%   (1) if tolerance and maximum iterations not specified
%
function [options] = setOptions(method,options)

% check if the debug option is set
if ~isfield(options,'debug')
    options.debug = 0;
else
    % set default debug step size
    if ~isfield(options,'debug')
        options.debugStep = 10;
    end
end

% check if termination tolerance specified
if ~isfield(options,'term_tol')
    warning('Termination tolerance not specified!!! Setting to default: 1e-6')
    options.term_tol = 1e-6;
end

% check if max iterations specified
if ~isfield(options,'max_iterations')
    warning('Maximum iterations not specified!!! Setting to default: 1e2')
    options.max_iterations = 1e2;
end

% ***Caution***: not a general way to identify trust region
% if ~isfield(method, 'step_type') 

% set options for trust region type method
if sum(strcmp(method.name, {'TRNewtonCG', 'TRSR1CG'}))
    % default parameters for trust region method
    if ~isfield(options,'c_1_tr')
        options.c_1_tr = 0.01;
    end
    if ~isfield(options,'c_2_tr')
        options.c_2_tr = 0.75;
    end
    % default initial radius of trust region
    if ~isfield(options,'delta0_tr')
        options.delta0_tr = 1;
    end
    % default maximum radius of trust region
    if ~isfield(options,'deltaMax_tr')
        options.deltaMax_tr = 1000;
    end
    % default rate of change of radius 
    if ~isfield(options,'rate_tr')
        options.rate_tr = 2;
    end
    % default parameters for conjugate gradient search
    if ~isfield(options,'term_tol_CG')
        options.term_tol_CG = 1e-2;     
    end
    if ~isfield(options,'max_iterations_CG')
        options.max_iterations_CG = 50;
    end
end

% set options for line search type method
if isfield(method, 'step_type')
    if sum(strcmp(method.step_type, {'Backtracking', 'Wolfe', 'Golden', 'Poly'}))
        if ~isfield(options,'c_1_ls')
            options.c_1_ls = 1e-4;
        end
        if ~isfield(options,'tau_ls')
            options.tau_ls = 0.5;
        end
        if ~isfield(options,'initial_step_size')
            options.initial_step_size = 1;
        end
        if strcmp(method.step_type, 'Wolfe')
            if ~isfield(options,'c_2_ls')
                options.c_2_ls = 0.5;
            end
            if ~isfield(options,'alpha_l')
                options.alpha_l = 0;
            end
            if ~isfield(options,'alpha_h')
                options.alpha_h = 1000;
            end 
        end
        if strcmp(method.step_type, 'Poly')
            if ~isfield(options,'gamma_high')
                options.gamma_h = 0.5;
            end
         
            if ~isfield(options,'gamma_low')
                options.gamma_l = 0.1;
            end        
        end      
    end
end

end