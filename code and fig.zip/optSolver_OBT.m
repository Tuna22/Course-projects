% IOE 511/MATH 562, University of Michigan
% Code written by: Weihui Gu

% Function that runs a chosen algorithm on a chosen problem
%           Inputs: problem, method, options (structs)
%           Outputs: final iterate (x) and final function value (f)
function [x,f,LogList] = optSolver_OBT(problem,method,options)

% set problem, method and options
[problem] = setProblem(problem);
[options] = setOptions(method,options);
[method]  = setMethod(method,problem,options);

if options.debug
    fprintf('\t%s start ... \n', method.name);
end

% results container
Nk = options.max_iterations;

% 
% function value, gradient, step size, time, error, sub-iteration
LogList = zeros(Nk,6);   

% compute initial function/gradient/Hessian
x = problem.x0;
f = problem.compute_f(x);
g = problem.compute_g(x);
norm_g = norm(g,inf);

% initial value
LogList(1,1:2) = [f,norm_g];       

% error bound
errMax = options.term_tol * max(1,norm_g);

% set initial iteration counter
k = 0;
tic;
while (norm_g > errMax) && (k < options.max_iterations)
    
    % take step according to a chosen method
    switch method.name
        case 'GradientDescent'
            [x_new,f_new,g_new,d,alpha,method] = GDStep(x,f,g,problem,method,options);
            
        case 'Newton'
            [x_new,f_new,g_new,d,alpha,method] = NMStep(x,f,g,problem,method,options);
            
        case 'TRNewtonCG'
            [x_new,f_new,g_new,d,alpha,method] = TRNewtonCGStep(x,f,g,problem,method,options);  
            
        case 'TRSR1CG'
            [x_new,f_new,g_new,d,alpha,method] = TRSR1CGStep(x,f,g,problem,method,options);

        case 'BFGS'
            [x_new,f_new,g_new,d,alpha,method] = BFGSStep(x,f,g,problem,method,options);
            
        case 'DFP'
            [x_new,f_new,g_new,d,alpha,method] = DFPStep(x,f,g,problem,method,options);    
            
        otherwise
            error('Method not implemented yet!')
            
    end
    % improvement of line search method
    if alpha >= 1
        options.initial_step_size = min(2*alpha,10);
    end
    % update old and new function values
    x = x_new; f = f_new; g = g_new; norm_g = norm(g,inf);
    % increment iteration counter
    k = k + 1;
    % store log data
    %err = norm(x-problem.xstar);
    LogList(k,:) = [f,norm_g,alpha,toc,0,method.sub_iter];   
    
    % tracking info. for debug
    if options.debug && mod(k,options.debugStep)==0
       fprintf('\t %d-th iter: f=%.2e, g=%.2e, a=%.2e, |d|=%.2e, t=%.2e ...\n',...
            k,f,norm_g,alpha,norm(d),LogList(k,4)-LogList(k-1,4));
    end
end

if isnan(norm_g)||isinf(norm_g)
    fprintf('\t %s fails with gradient being NaN!\n\n',method.name);
elseif (k==options.max_iterations)&&(norm_g > errMax)
    fprintf('\t %s fails with reaching the maxium iteration!\n\n',method.name);
else
    fprintf('\t %s finish:\n', method.name);
    fprintf('\t time=%.2e(s), f=%.2e, |g|=%.2e, iter=%d \n\n',LogList(k,4), f, norm_g, k);
end

LogList=LogList(1:k,:);  
end