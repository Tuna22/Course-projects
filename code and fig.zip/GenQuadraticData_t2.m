% Data generation script for quadratic type 2 problem
% Author: 04/07/2022 Weihui Gu
clc;clear;

strDir = 'problems/';
idPro = 6;  % problem index
sigma = 1e4;
Q = [5,1,0,0.5;
    1,4,0.5,0;
    0,0.5,3,0;
    0.5,0,0,2];
svd(Q)
[f] = quadratic_t2(Q,sigma);
x = ones(4,1);
test = f.hess(x);
angle = 70;
x0 = [cosd(angle) sind(angle) cosd(angle) sind(angle)]';
strName = sprintf('%sP%d_Quartic_%d/data.mat',strDir,idPro,idPro-4);
save(strName,'Q','sigma','x0');
close all;