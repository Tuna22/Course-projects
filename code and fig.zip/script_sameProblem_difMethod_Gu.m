% IOE 511/MATH 562, University of Michigan
% Code written by: Weihui Gu
close all; clear; clc;
% Use different method to solve the same problem
% 1. find the optimal solution of the problem as the benchmark
% 2. if a method has a poor performance, fine tune the parameter the method 
%    to improve its performance. Record the parameter.
% 3. If the method is still hard to solve the problem, give some reasoning
% (a) Is there something wrong with the method (code)? 
% (b) Is the method not capable to solve this type of problem due to its
%     inherent limitation?
% 
%% setproblem
addpath('problems/','solver');
% problem list
problemList = {'P1_quad_10_10','P2_quad_10_1000','P3_quad_1000_10',...
            'P4_quad_1000_1000','P5_Quartic_1','P6_Quartic_2',...
            'P7_Rosenbrock_2','P8_Rosenbrock_100','P9_DataFit_2',...
            'P10_Exponential_10','P11_Exponential_100','P12_Genhumps_5'};
% method list: method is the combination of method name and step-type
methodList = {'GradientDescent','Newton','BFGS','DFP','TRNewtonCG','TRSR1CG'};
stepTypeList={'Backtracking','Wolfe'};      % Golden
% what are the options of each method?
% No parameter for GD and Newton
% 
% parameters for backtracking: initial step size, c1, tau
% parameters for wolfe: initial step size, c1, tau, c2
% Parameter for Qusi-Newton method: (rank 2 update)
% BFGS: update inverse Hessian, PD safeguard 
% DFP:  update Hessian
% 
% Parameter for trust region with CG
% 1.Initial radius
% CG parameter
%% set options
% general option
options.term_tol = 1e-6;
options.max_iterations = 1e3;
options.debug = 0;
options.debugStep = 10;
%% ========================================================================
% problem selection
problemId = 12;
problem.name = problemList{problemId};
% load benchmark solution
load('NewtonBenchMark.mat','xstarList','dimXList');
problem.xstar=xstarList(1:dimXList(problemId),problemId);
% method selection
methodId = [1,1,2,2,3,3,4,4,5,6]'; 
stepTypeId = [1,2,1,2,1,2,1,2,1,1,1,1]';
% stepTypeId = ones(10,1);
% results container
Nmethod = length(methodId);
Nk = options.max_iterations;
fAll = zeros(Nk,Nmethod);       % function value vs. iteration
gAll = zeros(Nk,Nmethod);       % gradient value vs. iteration
tAll = zeros(Nk,Nmethod);       %          time  vs. iteration
aAll = zeros(Nk,Nmethod);       %     step size  vs. iteration
% 1.f 2.g 3.iter. 4.time
performanceList = zeros(Nmethod,4);
iterAll = zeros(Nmethod,1);
fprintf('Solve %s problem using... \n',problem.name);
for icase = 1:Nmethod    
    % method selection   
    method.name = methodList{methodId(icase)};
    method.step_type = stepTypeList{stepTypeId(icase)};
    method.dfp_PDcontrol = 1e-6; %1e-6
    % option selection
    if methodId(icase) < 5  % line search method
        fprintf('\tMethod %d: %s + %s\n',icase,method.name,method.step_type);
        switch method.step_type 
            case 'Backtracking'
            % option for Backtracking
            options.initial_step_size = 1;
            options.tau_ls = 0.5;
            options.c_1_ls = 1e-4;
            case 'Wolfe'
            % option for Wolfe
            options.initial_step_size = 1;
            options.tau_ls = 0.5;
            options.c_1_ls = 1e-4;
            
            options.c_2_ls = 0.5;
            options.alpha_h = 1000;
        end
    else  % Trust region (TR) related options
        fprintf('\tMethod %d: %s\n',icase,method.name);
        options.c_1_tr = 0.01;
        options.c_2_tr = 0.75;
        options.delta0_tr = 1e-2;       % how to select a initial delta0?
        options.rate_tr = 2;            % rate of changing radius of TR
        % Conjugate gradient related options
        options.term_tol_CG = 1e-4;     
        options.max_iterations_CG = 1e2;
        % should we set a upper bound on the delta
        % options.deltaMax_tr = 100*1e-2; 
    end
    % solve problem using the selected method
    [x,f,logList] = optSolver_OBT(problem,method,options);
    performanceList(icase,1:4) = [logList(end,1:2),length(logList(:,3)),logList(end,4)];
%     performanceList(icase,:) = [fList(end),gList(end),length(fList),tList(end)];
%     if icase == 7
%         testFlag = 1;
%     end
%     iterAll(icase) = performanceList(icase,3);
%     fAll(1:iterAll(icase),icase) = fList; 
%     gAll(1:iterAll(icase),icase) = gList; 
%     aAll(1:iterAll(icase),icase) = aList;  
%     tAll(1:iterAll(icase),icase) = tList;  
end
close;