%% Problem preparation
% We generate the Q matrix and strating point first and save them in the
% corresponding problems file as Data.mat
% P1-P4: call quadratic_t1(Q,q)
% P5-P6: call quadratic_t1(Q,sigma)
%% ===========================Progress log=================================
%% Part 1: problem initialization                                      done
%% Part 2: method implementation                                       done
% 1. GD:          done
% 2. GDW:
% 3. Newton:      done
% 4. NewtonW:
% 5. TRNewtonCG:  done
% 6. TRSR1:       done
% 7. BFGS:        done
% 8. BFGSW:       
% 9. DFP:         done
% 10:DFPW:        
%% *************
% 1. Wolfe: no while trapping 
   
%*********** 
DFP: What is difference between DFP and BFGS  ?
Improved Wolfe can help DFP
%% *************
%% Part 3: unify setup problem, method,option
% Report: finish the default option table
% Report: finish the description of method
%% Part 4: implement exact line search 
1. Golden segment: no gradient is required 
2. Quadratic interpolation: 
% Code: implement code                                      done

% test script for different LS method   *****  
Backtracking, Golden Section, Quadratic

samemethod with 3 LS
*********P6+GD+LS_GS fail


% Report: finish method description    
%% Part 5: Result part 1
% Finish table for performance
% 1.General comment for good result.
    %Overall method performance
% 2.Detail discussion for poor performance:
% 3.Overall method performance
% Discuss result format: figure form
% 
%% Part 6: Big question:
% fen

