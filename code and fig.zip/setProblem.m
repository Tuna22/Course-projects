% IOE 511/MATH 562, University of Michigan
% Code written by: Weihui Gu

% Function that specifies the problem. Specifically, a way to compute: 
%
%           Input: problem (struct), required (problem.name)
%           Output: problem (struct)
%
% Error(s): 
%       (1) if problem name not specified;
%       (2) the data is not available
%
function [problem] = setProblem(problem)

% check is problem name available
if ~isfield(problem,'name')
    error('Problem name not defined!!!')
end

if ~isfield(problem,'f')
    % initial f according to name
    switch problem.name  
        case 'P1_quad_10_10'
            strData = sprintf('problems/%s/data.mat',problem.name);
            load(strData,'Q','q','x0');
            problem.f = quadratic_t1(Q,q); 
        case 'P2_quad_10_1000' 
            strData = sprintf('problems/%s/data.mat',problem.name);
            load(strData,'Q','q','x0');
            problem.f = quadratic_t1(Q,q); 
        case 'P3_quad_1000_10' 
            strData = sprintf('problems/%s/data.mat',problem.name);
            load(strData,'Q','q','x0');
            problem.f = quadratic_t1(Q,q); 
        case 'P4_quad_1000_1000' 
            strData = sprintf('problems/%s/data.mat',problem.name);
            load(strData,'Q','q','x0');
            problem.f = quadratic_t1(Q,q); 
        case 'P5_Quartic_1' 
            strData = sprintf('problems/%s/data.mat',problem.name);
            load(strData,'Q','sigma','x0');
            problem.f = quadratic_t2(Q,sigma); 
        case 'P6_Quartic_2' 
            strData = sprintf('problems/%s/data.mat',problem.name);
            load(strData,'Q','sigma','x0');
            problem.f = quadratic_t2(Q,sigma); 
        case 'P7_Rosenbrock_2'    
            x0 = [-1.2; 1];
            problem.f = Rosen();  
        case 'P8_Rosenbrock_100'
            x0 = ones(100, 1);
            x0(1) = -1.2; 
            problem.f = Rosen();  
        case 'P9_DataFit_2'
            x0 = [1; 1];
            y = [1.5; 2.25; 2.625];
            problem.f = DataFit(y);              
        case 'P10_Exponential_10'
            problem.f = exponential_10();
            x0 = zeros(10,1);x0(1) = 1;
        case 'P11_Exponential_100'
            problem.f = exponential_100();
            x0 = zeros(100,1);x0(1) = 1;
        case 'P12_Genhumps_5'
            problem.f = genhumps_5();
            x0 = 506.2*ones(5,1); x0(1) = -1*x0(1);
        otherwise        
            error('Problem not defined!!!')
    end
end

% set starting point
if ~isfield(problem,'x0') 
    problem.x0 = x0;
end

% the dimension of the problem
problem.n = size(problem.x0,1);

% set function
problem.compute_f = problem.f.val;
problem.compute_g = problem.f.grad;
problem.compute_H = problem.f.hess;


end