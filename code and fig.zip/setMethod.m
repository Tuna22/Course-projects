% IOE 511/MATH 562, University of Michigan
% Code written by: Weihui Gu

% Function that specifies the method and method specific options. 
% 
%           Input: method (struct); required (method.name)
%           Output: method (struct)
%
% Error(s): 
%   (1) if method not specified
%
function [method] = setMethod(method,problem,option)

% check is method name specified
if ~isfield(method,'name')
    error('Method not specified!!!');
end

% check is step type specified
if ~isfield(method,'step_type')
    method.step_type = 'Backtracking';
end 

% initialize the sub-iteration's count
if ~isfield(method,'sub_iter')
    method.sub_iter = 0;
end 


switch method.name  
    case 'TRNewtonCG'
        % set initial radius for trust region
        if ~isfield(method,'delta')
            method.delta = option.delta0_tr;
        end
        
    case 'TRSR1CG'
        % set initial radius for trust region
        if ~isfield(method,'delta')
            method.delta = option.delta0_tr;
        end
        % set default initial Hessain for trust region
        if ~isfield(method,'B')
            n = length(problem.x0);
            method.B = eye(n);
        end
        % set default SR1 update threshold
        if ~isfield(method,'SR1_r')
            method.SR1_r = 1e-8;
        end

    case 'Newton'
        if ~isfield(method, 'newton_beta')
            method.newton_beta = 1e-6;
        end        

    case 'BFGS'
        if ~isfield(method, 'bfgs_PDcontrol')
            method.bfgs_PDcontrol = 1e-6;   %
        end
        method.bfgs.H = eye(problem.n);
    case 'DFP'
        if ~isfield(method, 'dfp_PDcontrol')
            method.dfp_PDcontrol = 1e-6;
        end
        method.dfp.c1_shrink = 1;
        method.dfp.H = eye(problem.n);
end
end