% Data generation script for quadratic type 1 problem
% Author: 04/07/2022 Weihui Gu
clc;clear;
strDir = 'problems/';
idPro = 3;  % problem index
n = 1000;
k = 10;     %condition number
strName = sprintf('%sP%d_quad_%d_%d/data.mat',strDir,idPro, n, k);
% random number seed
seed = 0;
rng(seed);
% Inputs: n, density, reciprocal of the condition number, and kind 
Q = sprandsym(n,0.5,1/k,1);
q = randn(n,1);
x0= 20*rand(n,1)-10;
save(strName,'Q','q','x0');
close all;