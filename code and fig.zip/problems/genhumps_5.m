% IOE 511/MATH 562, University of Michigan
% author: Jiayao Y
% 
% building function for problem, Genhumps_5, 
%
%       Input:  None
%       Output: functions(struct) 
%               with functions computing value, gradient, Hessian

function [f] = genhumps_5()
   %fprintf('initialing genhumps_5 ...')
   f.val = @(x)val(x);
   f.grad= @(x)grad(x);
   f.hess= @(x)hess(x);
end

function [f] = val(x)
    if size(x,1) ~= 5
        error('Error calling genhumps_5, dimensional should = 5 !!')
    end
    f = 0;
    for k = 1:4
        f = f+(sin(2*x(k)))^2*(sin(2*x(k+1)))^2 + 0.05*(x(k)^2 + x(k+1)^2);
    end
end
function [g] = grad(x)
    if size(x,1) ~= 5
        error('Error calling genhumps_5, dimensional should = 5 !!')
    end
    g = [4*sin(2*x(1))*cos(2*x(1))* sin(2*x(2))^2                  + 0.1*x(1);
     4*sin(2*x(2))*cos(2*x(2))*(sin(2*x(1))^2 + sin(2*x(3))^2) + 0.2*x(2);
     4*sin(2*x(3))*cos(2*x(3))*(sin(2*x(2))^2 + sin(2*x(4))^2) + 0.2*x(3);
     4*sin(2*x(4))*cos(2*x(4))*(sin(2*x(3))^2 + sin(2*x(5))^2) + 0.2*x(4);
     4*sin(2*x(5))*cos(2*x(5))* sin(2*x(4))^2                  + 0.1*x(5);];
end
function [H] = hess(x)
    H = zeros(5,5);

    H(1,1) =  8* sin(2*x(2))^2*(cos(2*x(1))^2 - sin(2*x(1))^2) + 0.1;
    H(1,2) = 16* sin(2*x(1))*cos(2*x(1))*sin(2*x(2))*cos(2*x(2));
    H(2,2) =  8*(sin(2*x(1))^2 + sin(2*x(3))^2)*(cos(2*x(2))^2 - sin(2*x(2))^2) + 0.2;
    H(2,3) = 16* sin(2*x(2))*cos(2*x(2))*sin(2*x(3))*cos(2*x(3));
    H(3,3) =  8*(sin(2*x(2))^2 + sin(2*x(4))^2)*(cos(2*x(3))^2 - sin(2*x(3))^2) + 0.2;
    H(3,4) = 16* sin(2*x(3))*cos(2*x(3))*sin(2*x(4))*cos(2*x(4));
    H(4,4) =  8*(sin(2*x(3))^2 + sin(2*x(5))^2)*(cos(2*x(4))^2 - sin(2*x(4))^2) + 0.2;
    H(4,5) = 16* sin(2*x(4))*cos(2*x(4))*sin(2*x(5))*cos(2*x(5));
    H(5,5) =  8* sin(2*x(4))^2*(cos(2*x(5))^2 - sin(2*x(5))^2) + 0.1;
    H(2,1) = H(1,2);
    H(3,2) = H(2,3);
    H(4,3) = H(3,4);
    H(5,4) = H(4,5);
    
end
