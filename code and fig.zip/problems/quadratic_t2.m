% IOE 511/MATH 562, University of Michigan
% Code written by: Weihui Gu

% Function structure for a quadratic type problem, include function for 
% computing the function value,gradeint, hessian
%
%           Input: Q(n,n), q(n,1)
%           Output: f(x)
%
function [f] = quadratic_t2(Q,sigma)
   f.val = @(x)val(Q,sigma,x);
   f.grad= @(x)grad(Q,sigma,x);
   f.hess= @(x)hess(Q,sigma,x);
end
function fx = val(Q,sigma,x)
    fx = (x'*Q*x)^2*sigma/4 + x'*x/2;
end

function gd = grad(Q,sigma,x)
    gd = (x'*Q*x)*(Q+Q.')*x*sigma + x; 
end
function h = hess(Q,sigma,x)
    n = length(x);
    h = eye(n) + sigma*(x'*Q*x)*Q+2*sigma*Q*(x*x')*Q;
%     term3_1 = 2*sigma*Q*(x*x')*Q;
%     term3 = zeros(n);
%     for i=1:n
%         for j=1:n
%             term3(i,j) = (Q(j,:)*x+x'*Q(:,j))*Q(i,:)*x;
%         end
%     end
%     err3 = term3_1-sigma*term3;
end

function gd = grad_v1(Q,sigma,x)
    gd = (Q+Q.')*x*sigma/2 + x; 
end
function h = hess_v1(Q,sigma,x)
    n = length(x);    
    h = eye(n) + (Q+Q.')*sigma/2;
end