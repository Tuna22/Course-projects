% IOE 511/MATH 562, University of Michigan
% Code written by: Weihui Gu

% Function structure for a quadratic type 1 problem, include function for 
% computing the function value,gradeint, hessian
%
%           Input: Q(n,n), q(n,1)
%           Output: f(x)
%
function [f] = quadratic_t1(Q,q)
   f.val = @(x)val(Q,q,x);
   f.grad= @(x)grad(Q,q,x);
   f.hess= @(x)hess(Q,x);
end
function fx = val(Q,q,x)
    fx = x'*Q*x/2 + q'*x;
end
function gd = grad(Q,q,x)
    gd = (Q+Q.')*x/2 + q; 
end
function h = hess(Q,x)
    h = (Q+Q.')/2;
end