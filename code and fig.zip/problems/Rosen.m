% IOE 511/MATH 562, University of Michigan
% Code written by: Tunan Wang

% Function structure for a Rosenbrock problem, include function for 
% computing the function value,gradeint, hessian
%
%           Input: Q(n,n), q(n,1)
%           Output: f(x)
%
function [f] = Rosen()
   f.val = @(x)val(x);
   f.grad= @(x)grad(x);
   f.hess= @(x)hess(x);
end
function fx = val(x)
    fx = sum((1 - x(1:(length(x)-1))).^2) + 100*sum((x(2:length(x)) - x(1:(length(x)-1)).^2).^2); 
end
function gd = grad(x)
    gd1 = [-2*(1-x(1:(length(x)-1))) - 400*x(1:(length(x)-1)).*(x(2:(length(x))) - x(1:(length(x)-1)).^2); 0];
    gd2 = [0 ; 200*(x(2:length(x)) - x(1:(length(x) - 1)).^2)];
    gd = [gd1 + gd2]; 
end
function h = hess(x)
    h1 = -400*x(1:(length(x)-1));
    h2 = [2 - 400*x(2:(length(x))) + 1200*x(1:(length(x)-1)).^2; 0];
    h3 = [0; 200*ones((length(x)-1), 1)];
    h = diag(h1, 1) + diag(h1, -1) + diag(h2 + h3);
end