% IOE 511/MATH 562, University of Michigan
% Code written by: Tunan Wang

% Function structure for a DataFit problem, include function for 
% computing the function value,gradeint, hessian
%
%           Input: Q(n,n), q(n,1)
%           Output: f(x)
%
function [f] = DataFit(y)
   f.val = @(x)val(x,y);
   f.grad= @(x)grad(x,y);
   f.hess= @(x)hess(x,y);
end
function fx = val(x,y)
    fx = 0;
  for i = 1:3
    fx = fx + (y(i) - x(1)*(1 - x(2)^i))^2;
  end
end
function gd = grad(x,y)
    gd = [0; 0];
   for i = 1:3
      gd = gd + [2*(x(2)^i - 1)*(y(i) - x(1)*(1 - x(2)^i)); 2*i*x(1)*x(2)^(i-1)*(y(i) - x(1)*(1 - x(2)^i))];
   end
end
function h = hess(x,y)
   h = [0, 0; 0, 2*x(1)*(2*y(2) - x(1)) + 6*x(1)^2*x(2)^2*(2 + 5*x(2)^2) + 12*x(1)*x(2)*(y(3) - x(1))];
   for i = 1:3
      h = h + [2*(x(2)^i - 1)^2, 2*i*x(2)^(i-1)*(y(i) + 2*x(1)*(x(2)^i - 1)); 2*i*x(2)^(i-1)*(y(i) + 2*x(1)*(x(2)^i - 1)) ,0];
   end
   
end