% IOE 511/MATH 562, University of Michigan
% author: Jiayao Y
%
% functions for computing the value,gradient,hessian of exponential_10
% problem
%
%           Input:  None (dimension specified: 10)
%           Output: functions(struct)

function [f] = exponential_10()
   %fprintf('initialing exponential_10 ...')
   f.val = @(x)val(x);
   f.grad= @(x)grad(x);
   f.hess= @(x)hess(x);
end
function [f] = val(x)
    if size(x,1) ~= 10
        error('Error calling exponential_10, dimensional should = 10 !!')
    end
    f = (exp(x(1,:))-1)./(exp(x(1,:))+1) + 0.1*exp(-x(1,:)) + sum((x(2:end,:)-1).^4,1);
end
function [g] = grad(x)
    if size(x,1) ~= 10
        error('Error calling exponential_10, dimensional should = 10 !!')
    elseif size(x,2) ~=1
            error('Error! exponential_10 can only compute gradient for one x at the same time !')
    else
    end
    n = length(x);
    g = zeros(n,1);
    g(1) = 2*exp(x(1))/( (exp(x(1)) + 1)^2 ) - 0.1* exp(-x(1));
    for i = 2:n
        g(i) = 4*(x(i) - 1)^3;
    end
end
function [H] = hess(x)
    if size(x,1) ~= 10
        error('Error calling exponential_10, dimensional should = 10 !!')
    elseif size(x,2) ~=1
            error('Error! exponential_10 can only compute Hessian for one x at the same time !')
    else
    end
    n = length(x);
    H = zeros(n,n);
    H(1,1) = 2*exp(x(1))*(1 - exp(x(1)))/( (exp(x(1)) + 1)^3 ) + 0.1* exp(-x(1));
    for i = 2:n
        H(i,i) = 12*(x(i) - 1)^2;
    end
end