% IOE 511/MATH 562, University of Michigan
% Code written by: Weihui Gu
close all; clear; clc;
% Apply same method to solve different problem
%% setproblem
addpath('problems/','solver');
problemList = {'P1_quad_10_10','P2_quad_10_1000','P3_quad_1000_10',...
            'P4_quad_1000_1000','P5_Quartic_1','P6_Quartic_2',...
            'P7_Rosenbrock_2','P8_Rosenbrock_100','P9_DataFit_2',...
            'P10_Exponential_10','P11_Exponential_100','P12_Genhumps_5'};
% methodList = {'GradientDescent','Newton','Golden','Poly'};
%% set options
% general option
options.term_tol = 1e-6;
options.max_iterations = 1e3;
options.debug = 0;
options.debugStep = 10;
%% set method
% methodList = {'GradientDescent','Newton','BFGS','DFP','TRNewtonCG','TRSR1CG'};
% method.name = methodList{4};
% step_typeList = {'Backtracking', 'Wolfe','Golden','Poly'};
% method.step_type = step_typeList{4};
% method.initial_step_size = 1;
% options.tau_ls = 0.5;
% options.c_1_ls = 1e-4;
% % wolfe
% options.c_2_ls = 0.5;
% options.alpha_h = 1000;
%% trust region
% method.name = 'TRSR1CG';
method.name = 'TRNewtonCG';
method.delta = 1;
% Trust region (TR) related options
% options.c_1_tr = 0.01;
% options.c_2_tr = 0.75;
options.term_tol_CG = 1e-2;         % Conjugate gradient related options
options.max_iterations_CG = 50;
% options.delta0_tr = 1;           % how to select a initial delta0?
options.deltaMax_tr=10^3;
% options.rate_tr = 2;                % rate of changing radius of TR
%% ========================================================================
fMin = -71687.9226770203; % P4
% fMin = 6.15E-05; %P6
% results container
problemId = [1:10,11,12]; 
Nproblem = length(problemId);
Nk = options.max_iterations;
fAll = zeros(Nk,Nproblem);       % function value vs. iteration
gAll = zeros(Nk,Nproblem);       % gradient value vs. iteration
tAll = zeros(Nk,Nproblem);       %          time  vs. iteration
aAll = zeros(Nk,Nproblem);       %     step size  vs. iteration
% 1.f 2.g 3.iter. 4.time
load('NewtonBenchMark.mat');
% xstarList = zeros(1000,Nproblem);
% dimXList = zeros(Nproblem,1);
subIterList = zeros(Nproblem,1);
performanceList = zeros(Nproblem,4);
iterAll = zeros(Nproblem,1); %
for icase = 1:Nproblem    
    problem.name = problemList{problemId(icase)};
    problem.xstar=xstarList(1:dimXList(icase),icase);
    fprintf('Test %d problem: %s\n',icase,problem.name);
    [x,f,logList] = optSolver_OBT(problem,method,options);
%     dimXList(icase) = length(x);
%     xstarList(1:dimXList(icase),icase) = x;
    performanceList(icase,1:4) = [logList(end,1:2),length(logList(:,3)),logList(end,4)];
%     subIterList(icase) = sum(logList(:,6));
%     Niter = size(logList,1);
%     f = logList(:,1);
%     figure;
%     semilogy(1:Niter,f-fMin);
%     xlabel('Iteration');
%     iterAll(icase) = performanceList(icase,3);
%     fAll(1:iterAll(icase),icase) = fList; 
%     gAll(1:iterAll(icase),icase) = gList; 
%     aAll(1:iterAll(icase),icase) = aList;  
%     tAll(1:iterAll(icase),icase) = tList; 
end
% save('NewtonBenchMark.mat','xstarList','dimXList');
close;