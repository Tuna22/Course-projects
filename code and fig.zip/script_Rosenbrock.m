% IOE 511/MATH 562, University of Michigan
% Code written by: Weihui Gu
% Script to test trust region method
close all; clear; clc;
%% setproblem
addpath('problems/','solver');
problemList = {'P1_quad_10_10','P2_quad_10_1000','P3_quad_1000_10',...
            'P4_quad_1000_1000','P5_Quartic_1','P6_Quartic_2',...
            'P7_Rosenbrock_2','P8_Rosenbrock_100','P9_DataFit_2',...
            'P10_Exponential_10','P11_Exponential_100','P12_Genhumps_5'};
%% set options: general option
options.term_tol = 1e-6;
options.max_iterations = 1e3;
options.debug = 0;
options.debugStep = 10;
%% set problem
problem.name = 'P7_Rosenbrock_2';
problem.x0 = [2,1]'; % set the starting point
%% Line search
method.name = 'Newton';
method.step_type = 'Wolfe';
% option for Wolfe
options.initial_step_size = 1;
options.tau_ls = 0.5;
options.c_1_ls = 1e-4;

options.c_2_ls = 0.3;
options.alpha_h = 1000;
fprintf('Start solving:...\n');
[x,f,logList] = optSolver_OBT(problem,method,options);
fprintf('\tSolution: x(%f,%f).\n',x(1),x(2));
fprintf('\tFinish!!!\n');

