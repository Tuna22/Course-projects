% IOE 511/MATH 562, University of Michigan
% Code written by: Weihui Gu
close all; clear; clc;
% Apply all methods with default option to solve different problems
%% Problem list
addpath('problems/','result');
% name of 12 problems
% problemList = { 'P1_quad_10_10',     'P2_quad_10_1000',      'P3_quad_1000_10',...
%                 'P4_quad_1000_1000', 'P5_Quartic_1',         'P6_Quartic_2',...
%                 'P7_Rosenbrock_2',   'P8_Rosenbrock_100',    'P9_DataFit_2',...
%                 'P10_Exponential_10','P11_Exponential_100',  'P12_Genhumps_5'};
% selection of method: 4 line search and 2 trust region 
% methodList = {'GradientDescent','Newton','BFGS','DFP','TRNewtonCG','TRSR1CG'};
% 4 step-type option for line search method
% stepTypeList = {'Backtracking', 'Wolfe','Golden','Poly'};
%% ========================================================================
% load benchmark solution
load('NewtonBenchMark.mat','xstarList','dimXList');
% load results
load('result\LogData.mat','problemList','methodList','methodIdList','stepTypeId',...
    'performanceTable','logTable');

% method selection
% methodIdList = [1,1,2,2,3,3,4,4,5,6]'; 
% stepTypeId = [1,2,1,2,1,2,1,2,1,1,1,1]';
% maximum of iteration
Nk = 1000;
Nmethod = length(methodIdList);
Nproblem= length(problemList);

% Performance table: (10 methods,4 metric, 12 problems)
% performanceTable = zeros(Nmethod,4,Nproblem);

% 6 metric: function value, gradient,step size, time, error, subiteration
% log container for all methods and problem
% Nmetric = 6;
% logTable = zeros(Nk,Nmetric,Nmethod,Nproblem);
%% same problem different method
strOut = 'result\';
strType= 'png';
% g vs. iteration
for idProblem = 7:Nproblem
performanceList = performanceTable(:,:,idProblem);
logList = logTable(:,:,:,idProblem);
plotIdList = 1:10; 
Nplot = length(plotIdList);

figure; hold on;    
set(gca,'DefaultLineLineWidth',1.2); set(gca,'FontSize',11);
set(gca,'FontWeight','bold');
for ii = 1:Nplot
    idMethod = plotIdList(ii);
    Niter = performanceList(idMethod,3);
    g = logList(1:Niter,2,idMethod);
    t = logList(1:Niter,4,idMethod);
    y = g;
    if mod(ii,2) == 0
        semilogy(t,y,'--'); hold on;
    else
        semilogy(t,y,'-'); hold on;
    end
end
legendList = {'GD','GDw','NM','NMw','BFGS','BFGSw','DFP','DFPw',...
               'TRNMCG','TRSR1CG'};
legend(legendList,'Location','Best','NumColumns',2); grid on;
xlabel('Time (s)'); ylabel('|g|');     set(gca,'Yscale','Log');
strTitle = sprintf('Gradient vs. time : P%d', idProblem);
title(strTitle);

% if idProblem == 3
%     xlim([0 80]);
% elseif idProblem == 7
%     xlim([0 200]);
% elseif idProblem == 9
%     xlim([0 50]);
% elseif idProblem == 2
%     xlim([0 250]);
% elseif idProblem == 4
%     xlim([0 550]);
% end
% save
strFigName = sprintf('P%d_g_time.%s',idProblem,strType);
saveas(gcf,[strOut,strFigName]);
end
close all;