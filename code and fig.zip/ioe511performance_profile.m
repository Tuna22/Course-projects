% ioe 511 calculating performance profile
%% w.r.t. iter
results = [46   1000    1000    1000    2   6   1000    42  530 18  9   32
46  1000    1000    1000    2   6   1000    42  530 33  15  23
1   1   1   1   2   5   18  6   11  12  12  48
1   1   1   1   2   5   17  6   11  12  12  35
51  54  59  300 3   19  33  112 17  19  11  97
37  52  41  317 3   20  44  112 14  16  12  47
48  161 48  541 3   11  106 44  14  14  14  37
44  209 42  497 3   12  145 28  21  13  12  105
8   12  11  22  3   5   31  4   7   12  13  49
13  19  37  265 3   23  79  71  20  18  18  65];

problem_solved = zeros(12,1000);
for k = 1:1000
    for i = 1:10
        problem_solved(i,k) = sum(results(i,:)<=k);
    end
end

% -- plot 1 ---

algo_name = ["GD","GDw","NM","NMw","BFGS","BFGSw","DFP","DFPw","TRNM","TRSr1"];
line_style = ["-","-","r-","k--","-","-","-","-","g-","-"];
figure()
set(gca,'DefaultLineLineWidth',1.2); 
for i = 1:10
%     plot(1:1000,problem_solved(i,:),line_style(i),'LineWidth',1);
    plot(1:1000,problem_solved(i,:),line_style(i),'LineWidth',1);
    hold on
end
hold off
legend(algo_name)
xlabel('Iteration')
ylabel('Number of solved problems')
xlim([0,200]);
legend(algo_name,'Location','Best','NumColumns',2)
set(gca,'FontWeight','bold');
set(gca,'FontSize',11); grid on;
title('Number of solved problems vs. iteration');
saveas(gcf,'perform_profile_iter.png');
%% with repect to time
results_t = [0.007326200    0.024288900 14.231324800    14.198363300    0.000123500 0.000277500 0.028866300 0.002272800 0.017789600 0.000447000 0.000284200 0.000643600
0.013768900 0.043199300 14.053160100    14.262272300    0.000084200 0.000263000 0.034836200 0.002637800 0.011908200 0.001082700 0.000497700 0.000509400
0.001816500 0.005559900 0.068010600 0.066699300 0.001450000 0.000323300 0.002452600 0.003266700 0.003818600 0.001353800 0.004788000 0.005509700
0.000738200 0.000491800 0.075299700 0.069843800 0.000164000 0.000304400 0.001059600 0.002185600 0.000841900 0.000638100 0.004081200 0.002728300
0.005418900 0.006737800 1.625595800 8.360127300 0.000178500 0.000795700 0.001557500 0.035380000 0.000732100 0.000865500 0.003592600 0.003442000
0.002555900 0.004874000 1.174030100 9.947889800 0.000172100 0.000952600 0.001845100 0.033795600 0.000582200 0.000820900 0.004440200 0.002420000
0.005287200 0.007802000 1.179481100 13.734314600    0.000181100 0.000509400 0.005062400 0.009297400 0.000499400 0.000611800 0.003810200 0.001520100
0.003749500 0.010721300 1.025766600 14.601238700    0.000174400 0.000560800 0.005794200 0.006555900 0.000821100 0.000660800 0.003643800 0.004694600
0.010772700 0.001863100 0.349190300 0.792871700 0.000502600 0.000286300 0.001144300 0.001292900 0.000398300 0.000536600 0.001884600 0.002250500
0.013333200 0.003333200 0.577611000 5.880542500 0.000158600 0.000871000 0.002785800 0.010733100 0.000797900 0.000821900 0.004195300 0.002970000];

%tend=max(max(results_t));
tend = 0.1;
time_p = linspace(0,tend,1000);
problem_solved_t = time_p;
for k = 1:1000
    for i = 1:10
        problem_solved_t(i,k) = sum(results_t(i,:)<=time_p(k));
    end
end

algo_name = ["GD","GDw","NM","NMw","BFGS","BFGSw","DFP","DFPw","TRNM","TRSr1"];
line_style = ["-","-","r-","k--","-","-","-","-","g-","-"];
figure()
set(gca,'DefaultLineLineWidth',1.2); 
set(gca,'FontWeight','bold');
for i = 1:10
    plot(time_p,problem_solved_t(i,:),line_style(i),'LineWidth',1);
    hold on
end
hold off
legend(algo_name)
xlabel('Time (s)')
ylabel('Number of solved problems')
% xlim([0,1]);
legend(algo_name,'Location','Best','NumColumns',2)
set(gca,'FontSize',11); grid on;
set(gca,'FontWeight','bold');
title('Number of solved problems vs. time');
saveas(gcf,'perform_profile_time.png');