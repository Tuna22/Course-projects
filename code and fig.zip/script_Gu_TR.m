% IOE 511/MATH 562, University of Michigan
% Code written by: Weihui Gu
% Script to test trust region method
close all; clear; clc;
%% setproblem
addpath('problems/','solver');
problemList = {'P1_quad_10_10','P2_quad_10_1000','P3_quad_1000_10',...
            'P4_quad_1000_1000','P5_Quartic_1','P6_Quartic_2',...
            'P7_Rosenbrock_2','P8_Rosenbrock_100','P9_DataFit_2',...
            'P10_Exponential_10','P11_Exponential_100','P12_Genhumps_5'};
idProblem = 4;
problem.name = problemList{idProblem};
%% set options
% general option
options.term_tol = 1e-6;
options.max_iterations = 1e3;
options.debug = 0;
options.debugStep = 10;
%% set problem
% problem.name = problemList{4};
%%
method.name = 'TRSR1CG';
% method.name = 'TRNewtonCG';
method.delta = 1;
options.term_tol_CG = 1e-2;         % Conjugate gradient related options
options.max_iterations_CG = 100;
% options.delta0_tr = 1;           % how to select a initial delta0?
options.deltaMax_tr=10^3;
% options.rate_tr = 2;                % rate of changing radius of TR
%% ========================================================================
% results container
Nmethod = 2;
Nk = options.max_iterations;
fAll = zeros(Nk,Nmethod);   aAll = zeros(Nk,Nmethod);
kAll = zeros(Nmethod,1);    
% fMin = zeros(Nmethod,2);
%% 
% delta0List = [1e-2,1,1e-2,1]; Ncase = length(delta0List);
% methodNameList = {'TRSR1CG','TRSR1CG','TRNewtonCG','TRNewtonCG'};
boundList = [10^3,10^30]; Ncase = length(boundList);    % test on bound
 methodNameList = {'TRSR1CG','TRSR1CG'};
for icase = 1:Ncase
    %method.delta = delta0List(icase);
    method.name = methodNameList{icase};
    method.deltaMax_tr = 
    [x,f,logList] = optSolver_OBT(problem,method,options);
    Niter = size(logList,1);
    kAll(icase) = Niter;
    fAll(1:Niter,icase) = logList(:,1);  
end
%% Test 1
% fMin = 5.55913017381142e-05; %P6
% figure; hold on;    
% set(gca,'DefaultLineLineWidth',1.2); set(gca,'FontSize',11);
% set(gca,'FontWeight','bold');
% plot(1:kAll(1), fAll(1:kAll(1),1)-fMin,'-'); hold on;
% plot(1:kAll(2), fAll(1:kAll(2),2)-fMin,'-'); hold on;
% plot(1:kAll(3), fAll(1:kAll(3),3)-fMin,'--'); hold on;
% plot(1:kAll(4), fAll(1:kAll(4),4)-fMin,'-'); hold on;
% legend('TRSR1CG: \Delta_0 = 0.01','TRSR1CG: \Delta_0 = 1',...
%         'TRNMCG: \Delta_0 = 0.01','TRNMCG: \Delta_0 = 1'); grid on;
% xlabel('Iteration'); ylabel('|f-f^*|');     set(gca,'Yscale','Log');
% title('Effects of \Delta_0 on trust region method');
% saveas(gcf,'TR_delta0.png');
%% Test2
% fMin = -71687.9226770203; % P4
% figure; hold on;    
% set(gca,'DefaultLineLineWidth',1.2); set(gca,'FontSize',11);
% set(gca,'FontWeight','bold');
% plot(1:kAll(1), fAll(1:kAll(1),1)-fMin,'-'); hold on;
% plot(1:kAll(2), fAll(1:kAll(2),2)-fMin,'-'); hold on;
% plot(1:kAll(3), fAll(1:kAll(3),3)-fMin,'--'); hold on;
% plot(1:kAll(4), fAll(1:kAll(4),4)-fMin,'-'); hold on;
% legend('TRSR1CG: \Delta_0 = 0.01','TRSR1CG: \Delta_0 = 1',...
%         'TRNMCG: \Delta_0 = 0.01','TRNMCG: \Delta_0 = 1'); grid on;
% xlabel('Iteration'); ylabel('|f-f^*|');     set(gca,'Yscale','Log');
% title('Effects of \Delta_0 on trust region method');
% saveas(gcf,'TR_delta0.png');