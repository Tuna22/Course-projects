% IOE 511/MATH 562, University of Michigan
% Code written by: Weihui Gu
close all; clear; clc;
% Apply all methods with default option to solve different problems
%% Problem list
addpath('problems/','result');
% name of 12 problems
% problemList = { 'P1_quad_10_10',     'P2_quad_10_1000',      'P3_quad_1000_10',...
%                 'P4_quad_1000_1000', 'P5_Quartic_1',         'P6_Quartic_2',...
%                 'P7_Rosenbrock_2',   'P8_Rosenbrock_100',    'P9_DataFit_2',...
%                 'P10_Exponential_10','P11_Exponential_100',  'P12_Genhumps_5'};
% selection of method: 4 line search and 2 trust region 
% methodList = {'GradientDescent','Newton','BFGS','DFP','TRNewtonCG','TRSR1CG'};
% 4 step-type option for line search method
% stepTypeList = {'Backtracking', 'Wolfe','Golden','Poly'};
%% ========================================================================
% load benchmark solution
load('NewtonBenchMark.mat','xstarList','dimXList');
% load results
load('resultLS\LogData_LS_raw.mat','problemList','methodList','methodIdList','stepTypeId',...
    'performanceTable','logTable');

% method selection
% methodIdList = [1,1,2,2,3,3,4,4,5,6]'; 
% stepTypeId = [1,2,1,2,1,2,1,2,1,1,1,1]';
% maximum of iteration
Nk = 1000;
Nmethod = length(methodIdList);
Nproblem= length(problemList);

% Performance table: (10 methods,4 metric, 12 problems)
% performanceTable = zeros(Nmethod,4,Nproblem);

% 6 metric: function value, gradient,step size, time, error, subiteration
% log container for all methods and problem
% Nmetric = 6;
% logTable = zeros(Nk,Nmetric,Nmethod,Nproblem);
%% same problem different method
strOut = 'resultLSraw\';
strType= 'png';
strMethod = 'GD';     plotIdList = 1:4; 
% strMethod = 'BFGS';     plotIdList = 5:8; 
% strMethod = 'DFP';     plotIdList = 9:12; 
% g vs. iteration
% xlimList = ones[]
for idProblem = 5:Nproblem
performanceList = performanceTable(:,:,idProblem);
logList = logTable(:,:,:,idProblem);
fMin = min(performanceList(:,1));
Nplot = length(plotIdList);
figure; hold on;    
set(gca,'DefaultLineLineWidth',1.2); set(gca,'FontSize',11);
set(gca,'FontWeight','bold');
for ii = 1:Nplot
    idMethod = plotIdList(ii);
    Niter = performanceList(idMethod,3);
    f = logList(1:Niter,1,idMethod);
    t = logList(1:Niter,4,idMethod);
    y = f-fMin;
    if find(y==0)
        id = find(y==0);
        y(id) =1e-16;
    end
    if mod(ii,2) == 0
        semilogy(t,y,'--'); hold on;
    else
        semilogy(t,y,'-'); hold on;
    end
end
legendList = {'Backtracking','Wolfe','Golden Section','Qua-Interpolation'};
legend(legendList,'Location','Best'); grid on;
% legend(legendList,'Location','Best','NumColumns',2); grid on;
xlabel('Time (s)'); ylabel('|f-f^*|');     set(gca,'Yscale','Log');
strTitle = sprintf('Error vs. time : P%d-%s',idProblem,strMethod);
title(strTitle);
% if idProblem == 3
%     xlim([0 80]);
% elseif idProblem == 7
%     xlim([0 200]);
% elseif idProblem == 9
%     xlim([0 50]);
% elseif idProblem == 2
%     xlim([0 250]);
% end
% save
strFigName = sprintf('P%d_LSraw_%s_f_time.%s',idProblem,strMethod,strType);
saveas(gcf,[strOut,strFigName]);
end
close all;
