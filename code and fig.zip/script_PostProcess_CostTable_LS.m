% IOE 511/MATH 562, University of Michigan
% Code written by: Weihui Gu
close all; clear; clc;
% Apply all methods with default option to solve different problems
%% Problem list
addpath('problems/','result');
% name of 12 problems
% problemList = { 'P1_quad_10_10',     'P2_quad_10_1000',      'P3_quad_1000_10',...
%                 'P4_quad_1000_1000', 'P5_Quartic_1',         'P6_Quartic_2',...
%                 'P7_Rosenbrock_2',   'P8_Rosenbrock_100',    'P9_DataFit_2',...
%                 'P10_Exponential_10','P11_Exponential_100',  'P12_Genhumps_5'};
% selection of method: 4 line search and 2 trust region 
% methodList = {'GradientDescent','Newton','BFGS','DFP','TRNewtonCG','TRSR1CG'};
% 4 step-type option for line search method
% stepTypeList = {'Backtracking', 'Wolfe','Golden','Poly'};
%% ========================================================================
% load benchmark solution
load('NewtonBenchMark.mat','xstarList','dimXList');
% load results
load('result\LogData_LS.mat','problemList','methodList','methodIdList','stepTypeId',...
    'performanceTable','logTable');

% method selection
% methodIdList = [1,1,2,2,3,3,4,4,5,6]'; 
% stepTypeId = [1,2,1,2,1,2,1,2,1,1,1,1]';
% maximum of iteration
Nk = 1000;
Nmethod = length(methodIdList);
Nproblem= length(problemList);
% Performance table: (10 methods,4 metric, 12 problems)
% performanceTable = zeros(Nmethod,4,Nproblem);

% 6 metric: function value, gradient,step size, time, error, subiteration
% log container for all methods and problem
% Nmetric = 6;
% logTable = zeros(Nk,Nmetric,Nmethod,Nproblem);

%% calculate # of function value and gradient evaluation
% # of main iter., sub tier, f, g
costTable = zeros(Nmethod,4,Nproblem);
% factor # of calculation with main- and sub-iteration
facGlist = zeros(Nmethod,2);
facGlist(1:4:12, 1) = 1;         % Backtracking
facGlist(2:4:12, 2) = 1;         % Wolfe
facGlist(3:4:12, 1) = 1;         % Golden
facGlist(4:4:12, 1) = 1;         % Poly = BT

facFlist = zeros(Nmethod,2);
facFlist(1:4:12, 2) = 1;         % Backtracking
facFlist(2:4:12, 2) = 1;         % Wolfe
facFlist(3:4:12, 1) = 4;         % Golden: 
facFlist(3:4:12, 2) = 1;         % 
facFlist(4:4:12, 2) = 1;         % Poly
for idProblem = 1:Nproblem
    performanceList = performanceTable(:,:,idProblem);
    logList = logTable(:,:,:,idProblem);
    costList = zeros(Nmethod,2);
    for idMethod = 1:Nmethod
        itMain = performanceList(idMethod,3);
        itSub = sum(logList(:,6,idMethod))+1;
        facF = facFlist(idMethod,:);
        facG = facGlist(idMethod,:);
        % # of main- and sub-iteration
        costList(idMethod,1:2) = [itMain,itSub];
        % # of f evalution
        costList(idMethod,3) = facF*[itMain;itSub];
        % # of g evalution
        costList(idMethod,4) = facG*[itMain;itSub];
    end
    costTable(:,:,idProblem) = costList;
end

save('result\LogData_LS.mat','problemList','methodList','methodIdList','stepTypeId',...
    'performanceTable','logTable','costTable');

