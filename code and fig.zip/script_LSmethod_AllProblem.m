% IOE 511/MATH 562, University of Michigan
% Code written by: Weihui Gu
close all; clear; clc;
% Apply all methods with default option to solve different problems
%% Problem list
addpath('problems/','solver');
% name of 12 problems
problemList = { 'P1_quad_10_10',     'P2_quad_10_1000',      'P3_quad_1000_10',...
                'P4_quad_1000_1000', 'P5_Quartic_1',         'P6_Quartic_2',...
                'P7_Rosenbrock_2',   'P8_Rosenbrock_100',    'P9_DataFit_2',...
                'P10_Exponential_10','P11_Exponential_100',  'P12_Genhumps_5'};
% selection of method: 4 line search and 2 trust region 
% methodList = {'GradientDescent','BFGS','DFP'};
methodList = {'GradientDescent','Newton','BFGS','DFP','TRNewtonCG','TRSR1CG'};
% 4 step-type option for line search method
stepTypeList = {'Backtracking', 'Wolfe','Golden','Poly'};
%% ========================================================================
% load benchmark solution
load('NewtonBenchMark.mat','xstarList','dimXList');
% method selection
methodIdList = [1,1,1,1,3,3,3,3,4,4,4,4]'; 
stepTypeId   = [1,2,3,4,1,2,3,4,1,2,3,4]';
% maximum of iteration
Nk = 1000;
Nmethod = length(methodIdList);
Nproblem= length(problemList);

% Performance table: (10 methods,4 metric, 12 problems)
performanceTable = zeros(Nmethod,4,Nproblem);
% 5 metric: function value, gradient,step size, time, error, subiteration
Nmetric = 6;

% log container for all methods and problem
logTable = zeros(Nk,Nmetric,Nmethod,Nproblem);

% default options
options.term_tol = 1e-6;
options.max_iterations = 1e3;
% options.debug = 1;
% options.debugStep = 10;
for idProblem = 1:Nproblem 
    % set problem
    problem.name = problemList{idProblem};   
    % set optimal solution
    problem.xstar=xstarList(1:dimXList(idProblem),idProblem);  
    % sub-container of 1 method: 1.f 2.g 3.iter. 4.time
    performanceList = zeros(Nmethod,4);
    fprintf('Start sovle problem: %s \n',problem.name);
    for idMethod = 1:Nmethod              
        % method selection   
        method.name = methodList{methodIdList(idMethod)};
        method.step_type = stepTypeList{stepTypeId(idMethod)};

        % solve problem using the selected method
        fprintf('\t==>Solve %s using %s with %s... \n',problem.name,...
                method.name, method.step_type);
        [x,f,logList] = optSolver_OBT(problem,method,options);
        
        Niter = size(logList,1);
        performanceList(idMethod,[1:2,4]) = logList(end,[1:2,4]);   
        performanceList(idMethod,3) = Niter;

        logTable(1:Niter,:,idMethod,idProblem) = logList;
    end
    performanceTable(:,:,idProblem) = performanceList;
end
% save log data
% strName = sprintf('Log
save('resultLS\LogData_LS_raw.mat','problemList','methodList','methodIdList','stepTypeId',...
    'performanceTable','logTable');
fprintf('Programe finished!');
% performanceList = performanceTable(:,:,12);
close;