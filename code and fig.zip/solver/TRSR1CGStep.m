function [x_new,f_new,g_new,d,alpha,method] = TRSR1CGStep(x,f,g,problem,method,options)
% Procedure of trust region step
% 1. compute searching direction: CG search
% 2. evaluate searching performance
% 3. update radius of trust region
% Ref: <<Num. Opt.>> Alg.4.1,P88 
% -----Input----- 
% x: starting point
% f: function value
% g: gradient at x
% delta: radius of the trust region
% method & option: 
% -----Output-----
% x_new,f_new,g_new
% d:        search direction
% alpha:    step size
% Date: 04/06/2022, Weihui Gu
%% calculate search direction
[d,iterCG] = TRCGdir(g,method.B,method.delta,options);
alpha = norm(d);
method.sub_iter = iterCG;
%% rho: performance measure
x_new = x+d;
f_new = problem.compute_f(x_new);
Bd = method.B*d;

% performance metric
ared = f - f_new;           % acutal rduection
pred = -g'*d - 1/2*d'*Bd;   % predicted rduection
rho = ared/pred;            

% fprintf('\t rho = %f\n', rho);
% update radius based on rho
if rho > options.c_1_tr
    % accept the update
    if rho > options.c_2_tr
        % increase radius of TR
        method.delta = min([options.rate_tr*method.delta,options.deltaMax_tr]);
%         method.delta = options.rate_tr*method.delta;
    end
    g_new = problem.compute_g(x_new);
    
    % update Hessian using SR1
    gd = g_new - g;
    denoSR1 = d'*(gd-Bd);
    if abs(denoSR1) > method.SR1_r*norm(d)*norm(gd-Bd)
        SR1 = (gd-Bd)*(gd-Bd)'/denoSR1;
        method.B = method.B + SR1;
    end

else 
    % reject the update
    %fprintf('\t *******rho = %f, reject TR update, iterCG=%d\n', rho,iterCG);
    x_new = x;  f_new = f;  g_new = g;  alpha = 0;
    % decrease radius of TR
    method.delta = method.delta/options.rate_tr;
end


end


