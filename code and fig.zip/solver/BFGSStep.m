% function for BFGS method
% author: jiayao y.
% 
% [x_new,f_new,g_new,d,alpha,method] = BFGSStep(x,f,g,problem,method,options)
%         Input:          x,f,g,problem,method,options
%         Output:         x_new,f_new,g_new,H_new,d,alpha,method
% H: the approximate inverse Hessian in previous iterate
%  

function [x_new,f_new,g_new,d,alpha,method] = BFGSStep(x,f,g,...
    problem,method,options)

% compute the search direction
d = - method.bfgs.H * g;

% initial step size
alpha = options.initial_step_size;

% determine stepsize
switch method.step_type
    case 'Backtracking'        
        [x_new,f_new,g_new,alpha,sub_iter]=LSbacktrack(x,f,g,d,problem,alpha,...
                        options.tau_ls,options.c_1_ls);
    case 'Wolfe'
        [x_new,f_new,g_new,alpha,sub_iter,sub_iter_g] = LSwolfe(x,f,g,d,problem,alpha,...
            options.alpha_h,options.alpha_l,options.tau_ls,...
            options.c_1_ls,options.c_2_ls);
        
    case 'Golden'
        [x_new,f_new,alpha,sub_iter] = LSGolden(x,d,problem,alpha);
        g_new = problem.compute_g(x_new);
        
    case 'Poly'   
        [x_new,f_new,g_new,alpha,sub_iter] = LSpoly(x,f,g,d,problem,alpha,...
                    options.gamma_h,options.gamma_l,options.c_1_ls);      
        
    otherwise
        error('this type of stepsize not implemented!')
end
method.sub_iter = sub_iter;

% compute new approximate inverse Hessian
sk = x_new - x;
yk = g_new - g;
% whether to update
if sk'*yk < method.bfgs_PDcontrol * norm(sk)*norm(yk)
else
    pk = 1/(yk'*sk);
%     Iden = eye(problem.n);
    %method.bfgs.H = (Iden - pk*sk*yk')*method.bfgs.H*(Iden - pk*yk*sk') + pk*sk*sk';
    method.bfgs.H = method.bfgs.H - (pk*sk)*(yk'*method.bfgs.H);
    method.bfgs.H = method.bfgs.H - (method.bfgs.H*yk)*(pk*sk)';
    method.bfgs.H = method.bfgs.H + (pk*sk)*sk';
end


end