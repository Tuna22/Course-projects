function [x_new,f_new,g_new,d,alpha,method] = TRNewtonCGStep(x,f,g,problem,method,options)
% Procedure of trust region step
% 1. compute searching direction: CG search
% 2. evaluate searching performanc
% 3. update radius of trust region
% Ref: <<Numerical optimiazion>> P171: Alg.7.2
% -----Input----- 
% x: starting point
% f: function value
% g: gradient at x
% delta: radius of the trust region
% method & option: 
% -----Output-----
% x_new,f_new,g_new
% d:        search direction
% alpha:    step size
% Date: 04/06/2022, Weihui Gu
%% calculate search direction

% compute hessian B
B = problem.compute_H(x);      

% use conjugate gradient to find search direction d
[d,iterCG] = TRCGdir(g,B,method.delta,options);
alpha = norm(d);
method.sub_iter = iterCG;
%% rho: performance measure
x_new = x+d;
f_new = problem.compute_f(x_new);

ared = f - f_new;               % acutal rduection
pred = -g'*d - 1/2*d'*B*d;      % predicted rduection
rho = ared/pred;                % performance metric

%% update TR radius
if rho > options.c_1_tr
    % accept the update
    if rho > options.c_2_tr
        % increase radius of TR
        method.delta = min([options.rate_tr*method.delta,options.deltaMax_tr]);
        %         method.delta = options.rate_tr*method.delta;
    end
    g_new = problem.compute_g(x_new);
else 
    % reject the update
    x_new = x;  f_new = f;  g_new = g;  alpha = 0;
    % decrease radius of TR
    method.delta = method.delta/options.rate_tr;
end

end


