function [x_new,f_new,g_new,alpha,sub_iter]=LSbacktrack(x,f,g,d,problem,alpha,tau,c1)
%% ========================================================================
% -----Description-----
% Compute step size using backtracking line search
% -----Input----- 
% x: starting point
% f: function value
% g: gradient at x
% d: searching direction
% problem: 
% -----Output-----
% x_new,f_new,g_new 
% Date: 02/15/2022, Weihui Gu
%% ========================================================================
% backtracking line search
    x_new = x + alpha*d;
    f_new = problem.compute_f(x_new);
    sub_iter = 1;
    while (f_new > f + c1*alpha*(g'*d)) 
        alpha = alpha * tau;
        x_new = x + alpha*d;
        f_new = problem.compute_f(x_new);
        sub_iter = sub_iter + 1;
    end
    g_new = problem.compute_g(x_new);
end