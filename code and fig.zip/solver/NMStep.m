function [x_new,f_new,g_new,d,alpha,method] = NMStep(x,f,g,problem,method,options)
%% ========================================================================
% -----Description-----
% Compute Newton step: search direction, step size
%       Computation:  O(n^3) computation for Hessian calculation
%       Meomry:       O(n^2)
% Ref: <<Num. Opt.>>  P44
% -----Input----- 
% x: starting point
% f: function value
% g: gradient at x
% problem: 
% method:
% -----Output-----
% x_new,f_new,g_new 
% d:        search direction
% alpha:    step size
% Date: 02/15/2022, Weihui Gu
%% ========================================================================
% Hessian
H = problem.compute_H(x);

% assign beta
beta = method.newton_beta;

% take out the minimum diag of H
A = min(diag(H));
eta = 0;

% calculate the initial modification parameter eta
if A <= 0
  eta = beta - A;
end
eta2 = eta*ones(1, length(H));

% try Cholesky
[R, flag] = chol(H + diag(eta2, 0));


% flag = 0 is sucessful 
while flag ~= 0 
  eta = max(beta, 2*eta);
  eta2 = eta*ones(1, length(H));
  [R, flag] = chol(H + diag(eta2, 0));
end

% compute the modified hessian
H = H + diag(eta2, 0);

% direction is -g/H
d = -H\g;

% initial step size
alpha = options.initial_step_size;
% determine step size
switch method.step_type
    case 'Backtracking'        
        [x_new,f_new,g_new,alpha,sub_iter] = LSbacktrack(x,f,g,d,problem,alpha,...
                            options.tau_ls,options.c_1_ls);        
    case 'Wolfe'
        [x_new,f_new,g_new,alpha,sub_iter,sub_iter_g] = LSwolfe(x,f,g,d,problem,alpha,...
            options.alpha_h,options.alpha_l,options.tau_ls,...
            options.c_1_ls,options.c_2_ls);
    case 'Golden'
        [x_new,f_new,alpha,sub_iter] = LSGolden(x,d,problem,alpha);
        g_new = problem.compute_g(x_new);
        
    case 'Poly'       
        [x_new,f_new,g_new,alpha,sub_iter] = LSpoly(x,f,g,d,problem,alpha,...
                            options.gamma_h,options.gamma_l,options.c_1_ls);
    otherwise
        error('this type of stepsize not implemented!')
            
end
method.sub_iter = sub_iter;
end

