% function for DFP method
% 
% [x_new,f_new,g_new,d,alpha,method] = DFPStep(x,f,g,H,problem,method,options)
%         Input:          x,f,g,problem,method,options
%         Output:         x_new,f_new,g_new,d,alpha,method
% H: the approximate inverse Hessian in previous iterate
%  

function [x_new,f_new,g_new,d,alpha,method] = DFPStep(x,f,g,...
    problem,method,options)

% compute the search direction
d = - method.dfp.H * g;

% initial step size
alpha = options.initial_step_size;

% determine stepsize
switch method.step_type
    case 'Backtracking'
        [x_new,f_new,g_new,alpha,sub_iter]=LSbacktrack(x,f,g,d,problem,alpha,...
                        options.tau_ls,options.c_1_ls);
    case 'Wolfe'
        [x_new,f_new,g_new,alpha,sub_iter,sub_iter_g] = LSwolfe(x,f,g,d,problem,alpha,...
            options.alpha_h,options.alpha_l,options.tau_ls,...
            options.c_1_ls,options.c_2_ls);
        
    case 'Golden'
        [x_new,f_new,alpha,sub_iter] = LSGolden(x,d,problem,alpha);
        g_new = problem.compute_g(x_new);
        
    case 'Poly'        
        [x_new,f_new,g_new,alpha,sub_iter] = LSpoly(x,f,g,d,problem,alpha,...
                        options.gamma_h, options.gamma_l,options.c_1_ls);        
        
    otherwise
        error('this type of stepsize not implemented!')
end
method.sub_iter = sub_iter;

% test
% fprintf('alpha=%f\n',alpha)
% if alpha < 1e-6
% %     method.dfp.c1_shrink = 0.5*method.dfp.c1_shrink;
%     fprintf('> DFP: alpha too small, shrinked the line search c1\n')
% end
% if alpha >0.9
%     method.dfp.c1_shrink = min(1.02*method.dfp.c1_shrink,0.99*10^4);
    
%     fprintf('> DFP: alpha=%.2f, increase the line search c1_shrink=%f\n',...
%         alpha,method.dfp.c1_shrink)
% end

% compute new approximate inverse Hessian
sk = x_new - x;
yk = g_new - g;

% scale the initial inverse Hessian approximation
if ~isfield(method,'dfp_init_scaler')
    method.dfp_init_scaler = 1;
    method.dfp.H = (yk'*sk)/(yk'*yk)*method.dfp.H;
    %fprintf('scale ..............')
end

% whether to update
if (sk'*yk < method.dfp_PDcontrol * norm(sk)*norm(yk))||(sk'*yk==0)
    if (sk'*yk==0)
        method.dfp.c1_shrink = 0.5*method.dfp.c1_shrink;
        
%         fprintf('c1:%f',method.dfp.c1_shrink);
%         fprintf('> DFP: inner prod = 0, shrinked the line search c1\n')
    end
else
    H = method.dfp.H;
%     pk = 1/(yk'*sk);
%     Iden = eye(problem.n);
    method.dfp.H = H - (H*yk)*(yk'*H)/(yk'*H*yk) + (sk*sk')/(yk'*sk);
end


end