function [x_new,f_new,g_new,alpha,sub_iter] = LSpoly(x,f,g,d,problem,alpha,gamma_h,gamma_l,c1)
%% ========================================================================
% -----Description-----
% Compute step size using polynomial line search with backtracking
% -----Input----- 
% x: starting point
% f: function value
% g: gradient at x
% d: searching direction
% problem: 
% -----Output-----
% x_new,f_new,g_new 
% Date: 02/15/2022, Weihui Gu
%% ========================================================================
    x_new = x + alpha*d;
    f_new = problem.compute_f(x_new);
    sub_iter = 1;
    
    while (f_new > f + c1*alpha*g'*d)
      alpha_new = (alpha^2 * g' * d) / 2*(f + alpha * g' * d - f_new);
      if alpha_new < gamma_l * alpha
          alpha = gamma_l * alpha;
      elseif alpha_new > gamma_h * alpha
          alpha = gamma_h * alpha;
      else
          alpha = alpha_new;
      end
      
      x_new = x + alpha*d;
      f_new = problem.compute_f(x_new); 
      sub_iter = sub_iter + 1;
    end
    g_new = problem.compute_g(x_new);     
end
