function [x_new,f_new,g_new,alpha,sub_iter,sub_iter_g] = LSwolfe(x,f,g,d,problem,alpha,alpha_h,alpha_l,tau,c1,c2)
% ================================================================
% the Wolfe conditions algorithm according to canvas notes
%% ========================================================================
% -----Description-----
% Compute step size using weak wolfe line search
% -----Input----- 
% x: starting point
% f: function value
% g: gradient at x
% d: searching direction
% problem: 
% -----Output-----
% x_new,f_new,g_new 
% Date: 02/15/2022, Weihui Gu
%% ========================================================================
    kWolfe = 1;
    kWolfeMax = 30;
    x_new = x + alpha*d;
    f_new = problem.compute_f(x_new);
    g_count = 0;
    while kWolfe < kWolfeMax
        if f + c1*alpha*(g'*d) >= f_new
            g_new = problem.compute_g(x+alpha*d);
            g_count = g_count + 1;
            if g_new'*d >= c2*g'*d
                break
            else
                alpha_l = alpha;
            end
        else
            alpha_h = alpha;
        end
        alpha = tau*alpha_l + (1-tau)*alpha_h;
        %fprintf('counter=%d, alpha=%f\n',counter,alpha);
        kWolfe = kWolfe + 1;
        x_new = x + alpha*d;
        f_new = problem.compute_f(x_new);
    end
    if kWolfe == kWolfeMax
        fprintf('\t Warning: Wolfe search reach iteration limit %d, use Backtracking\n',...
                kWolfe);
        [x_new,f_new,g_new,alpha]=LSbacktrack(x,f,g,d,problem,alpha,tau,c1);
    end
    sub_iter = g_count; %kWolfe
    sub_iter_g = g_count;
    
    %fprintf('\t total Wolfe search=%d, alpha=%f\n',kWolfe,alpha);
end
