function [p,iterCG] = TRCGdir(g,B,delta,options)
% Conjugate Gradient (CG) substep to find new serch dirction for Trust Region (TR)
% 
% Input: 
%   g: gradient
%   delta: radius of trust region
%   options: option for CG method
% 
% Output:
%    p: searching direction
% Date: 04/06/2022, Weihui Gu 
%% initialization
n = length(g);
z = zeros(n,1);     % starting point
r = g;              % residual 
d = -r;             % searching direction

errMax = options.term_tol_CG*norm(g); % tolerance of CG method
% errMax = min(0.01,sqrt(norm(g)))*norm(g);
% if norm(r) < options.term_tol_CG
%     p = d;
% end

% find optimal direction and step size using conjugate gradient 
norm_r = norm(r);
iterCG = 1;
while (norm_r > errMax) && (iterCG <options.max_iterations_CG)
    iterCG = iterCG + 1;
    Bd = B*d;                       % O(n^2)
    deno = d'*Bd;
    
    % (1) concave objective function: optimal solution hits the TR boundary
    if deno < 0
       [z,tau] = TRCGtau(g,B,z,d,delta);      % solve for tau
       %fprintf('\t case 1 concave B: tau = %f, %d CG search\n', tau,iterCG);
       break;
    end

    alpha = norm_r^2/deno;          % CG step size
    z = z + alpha*d;                % new point
    
    % (2) searching reach to the TR boundary
    if norm(z) > delta
        [z,tau] = TRCGtau(g,B,z,d,delta);     % solve for tau
        %fprintf('\t case 2 CG hit boundary: tau = %f, %d CG search\n', tau,iterCG);
        break;
    end
    
    % (3) acieve desire accuracy within TR
    rp1 = r + alpha*Bd;
    if norm(rp1) < errMax
        %fprintf('\t case 3 CG success, %d CG search:\n', iterCG);
        break
    end
    
    % update CG iterate
    beta = rp1'*rp1/norm_r^2;             % searching coefficient
    d = -rp1 + beta*d;              % new searching direction
    r = rp1;
    norm_r= norm(r);
end 
p = z;
% fprintf('\t iterCG = %d\n',iterCG);
end






