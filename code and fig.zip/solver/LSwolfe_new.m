function [x_new,f_new,g_new,alpha] = LSwolfe(x,f,g,d,problem,alpha,alpha_h,alpha_l,tau,c1,c2)
%% ========================================================================
% -----Description-----
% Compute step size using weak wolfe line search
% -----Input----- 
% x: starting point
% f: function value
% g: gradient at x
% d: searching direction
% problem: 
% -----Output-----
% x_new,f_new,g_new 
% Date: 02/15/2022, Weihui Gu
%% ========================================================================
    x_new = x + alpha*d;
    f_new = problem.compute_f(x_new);
    g_new = problem.compute_g(x_new);
    alpha_h0 = alpha_h;
    
  if problem.k < 1000
    while (f_new > f + c1*alpha*g'*d)||(g_new'*d < c2*g'*d)
      if (f_new > f + c1*alpha*g'*d)
          % sufficient decrease fail
          alpha_h = alpha;
          alpha = (1 - tau)*alpha_h + tau*alpha_l;
      else
          % sufficient decrease success
          alpha_l = alpha;
          if alpha_h == alpha_h0
            alpha = 2*alpha_l;  % can be changed
          else
            alpha = (1 - tau)*alpha_h + tau*alpha_l;
          end
      end
      
      x_new = x + alpha*d;
      f_new = problem.compute_f(x_new);
      g_new = problem.compute_g(x_new);  
    end
    
  else 
%     while f_new > f + c1*alpha*g'*d
%         alpha = tau * alpha;
%         x_new = x + alpha*d;
%         f_new = problem.compute_f(x_new);
%       end
%     g_new = problem.compute_g(x_new);
   end

end
