function [x_new,f_new,alpha,sub_iter]=LSGolden(x,d,problem,alpha)
%% ========================================================================
% -----Description-----
% Compute step size using Golden section line search
% -----Input----- 
% x: starting point
% f: function value
% d: searching direction
% problem: 
% -----Output-----
% x_new,f_new,alpha 
%% ========================================================================
% Golden section line search
    % [a, lam, mu, b]
    ls_eps = 1e-5;
    a = 0; b = alpha;
    lam = a + 0.382*(b-a);
    mu = a + 0.618*(b-a);
    sub_iter = 1;
    f1 = problem.compute_f(x+a*d);
    f2 = problem.compute_f(x+lam*d);
    f3 = problem.compute_f(x+mu*d);
    f4 = problem.compute_f(x+b*d);
    while 1
        %if problem.compute_f(x + lam*d) > problem.compute_f(x + mu*d)
        if f2 > f3
            if b - lam < ls_eps
                alpha = mu;
                break
            end
            if f2 < f1
                a = lam;
                lam = mu;
                mu = a + 0.618*(b-a);
                f1 = f2;f2 = f3;f3 = problem.compute_f(x+mu*d);
            else
                b = mu;
                mu = lam;
                lam = a + 0.382*(b-a);
                f4 = f3; f3=f2; f2 = problem.compute_f(x+lam*d);
            end
        else
            if mu - a < ls_eps
                alpha = lam;
                break
            end
            b = mu;
            mu = lam;
            lam = a + 0.382*(b-a);
            f4 = f3; f3=f2; f2 = problem.compute_f(x+lam*d);
        end
        sub_iter = sub_iter + 1;
    end
%     fprintf('[%f\t%f\t%f\t%f]\n',a,lam,mu,b);
    x_new = x + alpha*d; 
    f_new = problem.compute_f(x_new);
end
