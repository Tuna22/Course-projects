function [p1,tau1] = TRCGtau(g,B,z,d,r)
% given direction z,d, 
% 1.find tau minimize m(z+tau*d)
% 2.norm(z+tau*d)=r 
% Date: 04/07/2022, Weihui Gu 

%% coefficient of quadratic function
a = d'*d;
b = 2*d'*z;
c = z'*z-r^2;
% first solution
tau1 = (-b+sqrt(b^2-4*a*c))/(2*a);
p1 = z+tau1*d;
mp1 = g'*p1 + 1/2*p1'*B*p1;
% second solution
tau2 = (-b-sqrt(b^2-4*a*c))/(2*a);
p2 = z+tau2*d;
mp2 = g'*p2 + 1/2*p2'*B*p2;
% find the one minimize the model
if mp1 > mp2
    p1 = p2;
    tau1 = tau2;
end
end